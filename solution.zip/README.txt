MS1:
Madhu: sender implementation
Ryan: reciever implementaion

Both did connection, any shared utils stuff

Sample README.txt

Eventually your report about how you implemented thread synchronization
in the server should go here
